import { world, MolangVariableMap } from "@minecraft/server";
import { playSound } from "../utils";
const entityParticles = {
  chest_minecart: [],
  minecart: [],
  command_block_minecart: [],
  hopper_minecart: [],
  tnt_minecart: [],
  ender_crystal: [],
  armor_stand: [],
  boat: [],
  balloon: [],
  chest_boat: [],
  magma_cube: [],
  item: [],
  leash_knot: [],
  "ra:rpg_rocket.projectile": [],
  "ra:menu_holder": [],
  "ra:ak_47_clip_golden": [],
  "ra:ak_47_clip": [],
  "ra:rpk_clip": [],
  "ra:rpk_drum": [],
  "ra:desert_eagle_clip": [],
  "ra:mini_gun_clip": [],
  "ra:shotgun_shell": [],
  "ra:sniper_casing": [],
  "ra:thunder_gun_clip": [],
  "ra:drop_item": [],
  "ra:zombie_spawn_point": [],
  "ra:barricade": [],
  "ra:power_up": [],
  "ra:garand_clip": [],
  "ra:mosin_clip": [],
  "ra:m16a4_clip": [],
  "ra:m4a1_clip": [],
  "ra:scar_clip": [],
  "ra:scar_black_clip": [],
  "ra:m79_grenade.projectile": [],
  "ra:m79_casing": [],
  "ra:dirty.droplets": [],
  "ra:shell.dirty": [],
  "ra:shell.fire": [],
  "ra:shell.smoke": [],
  "ra:incendiary_grenade.projectile": [],
  "ra:dirty_grenade.projectile": [],
  "ra:smoke_grenade.projectile": [],
  "ra:confetti_grenade.projectile": [],
  iron_golem: ["ra:bullet.impact_1", "ra:bullet.impact_sparks", "ra:bullet.impact_sparks", "ra:bullet.impact_small"],
  blaze: ["ra:bullet.impact_sparks", "ra:bullet.impact_small"],
  shulker: [],
  vex: [],
  snow_golem: [],
  slime: ["ra:spider.hurt_blood", "ra:spider.hurt_bits", "ra:bullet.impact_spider"],
  cave_spider: ["ra:spider.hurt_blood", "ra:spider.hurt_bits", "ra:bullet.impact_spider"],
  spider: ["ra:spider.hurt_blood", "ra:spider.hurt_bits", "ra:bullet.impact_spider"],
  // warden: [],
  skeleton_horse: ["ra:skeleton.spine_hit", "ra:skeleton.spine_hit.1"],
  skeleton: ["ra:skeleton.spine_hit", "ra:skeleton.spine_hit.1"],
  wither_skeleton: [],
  wither: [],
  stray: [],
  pig: ["ra:hurt_blood", "ra:hurt_blood", "ra:zombie.hurt_bits", "ra:bullet.impact_zombie", "ra:bullet.impact_zombie"],
  cow: ["ra:hurt_blood", "ra:hurt_blood", "ra:zombie.hurt_bits", "ra:bullet.impact_zombie", "ra:bullet.impact_zombie"],
  creaking: ["ra:creaking.wood_smoke", "ra:creaking.wood_chips"],
  "ra:target": ["ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  "ra:target_game": ["ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  "ra:z_game": ["ra:hurt_blood", "ra:bullet.impact_zombie", "ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  "ra:grenade.projectile": ["ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  "ra:grenade.projectile_landed": ["ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  "ra:weapon_display": ["ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  "ra:weapon_display_spruce": ["ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  "ra:weapon_display_birch": ["ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  "ra:weapon_display_jungle": ["ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  "ra:weapon_display_acacia": ["ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  "ra:weapon_display_dark_oak": ["ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  "ra:weapon_display_mangrove": ["ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  "ra:weapon_display_crimson": ["ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  "ra:weapon_display_warped": ["ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  "ra:weapon_display_cherry": ["ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  "ra:weapon_display_bamboo": ["ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  "ra:weapon_display_pale_oak": ["ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  "ra:weapon_display_iron": ["ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  "ra:weapon_display_copper": ["ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  "ra:weapon_display_diamond": ["ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  "ra:weapon_display_gold": ["ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  "ra:weapon_display_emerald": ["ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  "ra:weapon_display_netherite": ["ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  "ra:weapon_display_glowstone": ["ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  "ra:weapon_display_redstone": ["ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  default: ["ra:hurt_blood", "ra:zombie.hurt_bits", "ra:bullet.impact_zombie"],
};
const sounds = {
  chest_minecart: [],
  minecart: [],
  command_block_minecart: [],
  hopper_minecart: [],
  tnt_minecart: [],
  ender_crystal: [],
  armor_stand: [],
  boat: [],
  chest_boat: [],
  iron_golem: [],
  slime: [],
  magma_cube: [],
  item: [],
  "ra:rpg_rocket.projectile": [],
  "ra:menu_holder": [],
  "ra:ak_47_clip_golden": [],
  "ra:ak_47_clip": [],
  "ra:rpk_clip": [],
  "ra:rpk_drum": [],
  "ra:desert_eagle_clip": [],
  "ra:mini_gun_clip": [],
  "ra:shotgun_shell": [],
  "ra:sniper_casing": [],
  "ra:thunder_gun_clip": [],
  "ra:drop_item": [],
  "ra:target": [],
  "ra:target_game": [],
  "ra:z_game": [],
  "ra:grenade.projectile": [],
  "ra:grenade.projectile_landed": [],
  "ra:zombie_spawn_point": [],
  "ra:barricade": [],
  "ra:power_up": [],
  "ra:garand_clip": [],
  "ra:mosin_clip": [],
  "ra:m16a4_clip": [],
  "ra:m4a1_clip": [],
  "ra:scar_clip": [],
  "ra:scar_black_clip": [],
  "ra:m79_grenade.projectile": [],
  "ra:m79_casing": [],
  "ra:dirty.droplets": [],
  "ra:shell.dirty": [],
  "ra:shell.fire": [],
  "ra:shell.smoke": [],
  "ra:incendiary_grenade.projectile": [],
  "ra:dirty_grenade.projectile": [],
  "ra:smoke_grenade.projectile": [],
  "ra:confetti_grenade.projectile": [],
  "ra:limb_jar.empty": [{ id: "random.glass", pitch: 1.25, volume: 1.75 }],
  "ra:limb_jar": [{ id: "random.glass", pitch: 1.25, volume: 1.75 }],
  "ra:limb_jar.1": [{ id: "random.glass", pitch: 1.25, volume: 1.75 }],
  "ra:limb_jar.dead": [{ id: "random.glass", pitch: 1.25, volume: 1.75 }],
  "ra:limb_jar.dead.1": [{ id: "random.glass", pitch: 1.25, volume: 1.75 }],
  "ra:limb_jar.limb": [{ id: "random.glass", pitch: 1.25, volume: 1.75 }],
  "ra:limb_jar.spine": [{ id: "random.glass", pitch: 1.25, volume: 1.75 }],
  "ra:limb_jar.gib": [{ id: "random.glass", pitch: 1.25, volume: 1.75 }],
  "ra:limb_jar.gib.1": [{ id: "random.glass", pitch: 1.25, volume: 1.75 }],
  "ra:limb_jar.gib.2": [{ id: "random.glass", pitch: 1.25, volume: 1.75 }],
  "ra:limb_jar.gib_head": [{ id: "random.glass", pitch: 1.25, volume: 1.75 }],
  "ra:limb_jar.gib_head.1": [{ id: "random.glass", pitch: 1.25, volume: 1.75 }],
  "ra:limb_jar.gib_head_h": [{ id: "random.glass", pitch: 1.25, volume: 1.75 }],
  "ra:limb_jar.gib_head_h.1": [{ id: "random.glass", pitch: 1.25, volume: 1.75 }],
  blaze: [],
  shulker: [],
  balloon: [],
  vex: [],
  snow_golem: [],
  cave_spider: [{ id: "splat_impact", pitch: 1.5, volume: 0.45 }],
  spider: [{ id: "splat_impact", pitch: 1.5, volume: 0.45 }],
  warden: [],
  skeleton_horse: [
    [
      { id: "hit.bone_block", pitch: 0.75, volume: 0.65 },
      { id: "hit.bone_block", pitch: 0.25, volume: 0.45 },
    ],
  ],
  skeleton: [
    [
      { id: "hit.bone_block", pitch: 0.75, volume: 0.65 },
      { id: "hit.bone_block", pitch: 0.25, volume: 0.45 },
    ],
  ],
  wither_skeleton: [
    [
      { id: "hit.bone_block", pitch: 0.75, volume: 0.65 },
      { id: "hit.bone_block", pitch: 0.25, volume: 0.45 },
    ],
  ],
  wither: [],
  stray: [],
  creaking: [
    [
      { id: "block.mangrove_roots.break", pitch: 0.75, volume: 0.65 },
      { id: "block.mangrove_roots.break", pitch: 0.5, volume: 0.25 },
    ],
  ],
  "ra:weapon_display": [
    [
      { id: "block.mangrove_roots.break", pitch: 0.75, volume: 0.65 },
      { id: "block.mangrove_roots.break", pitch: 0.5, volume: 0.25 },
    ],
  ],
  "ra:weapon_display_spruce": [
    [
      { id: "block.mangrove_roots.break", pitch: 0.75, volume: 0.65 },
      { id: "block.mangrove_roots.break", pitch: 0.5, volume: 0.25 },
    ],
  ],
  "ra:weapon_display_birch": [
    [
      { id: "block.mangrove_roots.break", pitch: 0.75, volume: 0.65 },
      { id: "block.mangrove_roots.break", pitch: 0.5, volume: 0.25 },
    ],
  ],
  "ra:weapon_display_jungle": [
    [
      { id: "block.mangrove_roots.break", pitch: 0.75, volume: 0.65 },
      { id: "block.mangrove_roots.break", pitch: 0.5, volume: 0.25 },
    ],
  ],
  "ra:weapon_display_acacia": [
    [
      { id: "block.mangrove_roots.break", pitch: 0.75, volume: 0.65 },
      { id: "block.mangrove_roots.break", pitch: 0.5, volume: 0.25 },
    ],
  ],
  "ra:weapon_display_dark_oak": [
    [
      { id: "block.mangrove_roots.break", pitch: 0.75, volume: 0.65 },
      { id: "block.mangrove_roots.break", pitch: 0.5, volume: 0.25 },
    ],
  ],
  "ra:weapon_display_mangrove": [
    [
      { id: "block.mangrove_roots.break", pitch: 0.75, volume: 0.65 },
      { id: "block.mangrove_roots.break", pitch: 0.5, volume: 0.25 },
    ],
  ],
  "ra:weapon_display_crimson": [
    [
      { id: "block.mangrove_roots.break", pitch: 0.75, volume: 0.65 },
      { id: "block.mangrove_roots.break", pitch: 0.5, volume: 0.25 },
    ],
  ],
  "ra:weapon_display_warped": [
    [
      { id: "block.mangrove_roots.break", pitch: 0.75, volume: 0.65 },
      { id: "block.mangrove_roots.break", pitch: 0.5, volume: 0.25 },
    ],
  ],
  "ra:weapon_display_cherry": [
    [
      { id: "block.mangrove_roots.break", pitch: 0.75, volume: 0.65 },
      { id: "block.mangrove_roots.break", pitch: 0.5, volume: 0.25 },
    ],
  ],
  "ra:weapon_display_bamboo": [
    [
      { id: "block.mangrove_roots.break", pitch: 0.75, volume: 0.65 },
      { id: "block.mangrove_roots.break", pitch: 0.5, volume: 0.25 },
    ],
  ],
  "ra:weapon_display_pale_oak": [
    [
      { id: "block.mangrove_roots.break", pitch: 0.75, volume: 0.65 },
      { id: "block.mangrove_roots.break", pitch: 0.5, volume: 0.25 },
    ],
  ],
  "ra:weapon_display_copper": [
    [
      { id: "block.mangrove_roots.break", pitch: 0.75, volume: 0.65 },
      { id: "block.mangrove_roots.break", pitch: 0.5, volume: 0.25 },
    ],
  ],
  "ra:weapon_display_diamond": [
    [
      { id: "block.mangrove_roots.break", pitch: 0.75, volume: 0.65 },
      { id: "block.mangrove_roots.break", pitch: 0.5, volume: 0.25 },
    ],
  ],
  "ra:weapon_display_emerald": [
    [
      { id: "block.mangrove_roots.break", pitch: 0.75, volume: 0.65 },
      { id: "block.mangrove_roots.break", pitch: 0.5, volume: 0.25 },
    ],
  ],
  "ra:weapon_display_glowstone": [
    [
      { id: "block.mangrove_roots.break", pitch: 0.75, volume: 0.65 },
      { id: "block.mangrove_roots.break", pitch: 0.5, volume: 0.25 },
    ],
  ],
  "ra:weapon_display_gold": [
    [
      { id: "block.mangrove_roots.break", pitch: 0.75, volume: 0.65 },
      { id: "block.mangrove_roots.break", pitch: 0.5, volume: 0.25 },
    ],
  ],
  "ra:weapon_display_iron": [
    [
      { id: "block.mangrove_roots.break", pitch: 0.75, volume: 0.65 },
      { id: "block.mangrove_roots.break", pitch: 0.5, volume: 0.25 },
    ],
  ],
  "ra:weapon_display_netherite": [
    [
      { id: "block.mangrove_roots.break", pitch: 0.75, volume: 0.65 },
      { id: "block.mangrove_roots.break", pitch: 0.5, volume: 0.25 },
    ],
  ],
  "ra:weapon_display_redstone": [
    [
      { id: "block.mangrove_roots.break", pitch: 0.75, volume: 0.65 },
      { id: "block.mangrove_roots.break", pitch: 0.5, volume: 0.25 },
    ],
  ],
  "ra:mystery_box": [
    [
      { id: "gold_loot", pitch: 1.25, volume: 0.15 },
      { id: "gold_loot1", pitch: 0.75, volume: 0.05 },
    ],
  ],
  default: [
    { id: "splat_impact", pitch: 1.5, volume: 0.45 },
    [
      { id: "hit.bone_block", pitch: 0.75, volume: 0.65 },
      { id: "hit.bone_block", pitch: 0.25, volume: 0.45 },
    ],
  ],
};
world.afterEvents.projectileHitEntity.subscribe((ev) => {
  const proj = ev.projectile;
  try {
    if (proj.typeId != "ra:bullet.projectile") return;
  } catch {
    return;
  }
  const entityHit = ev.getEntityHit();
  if (!entityHit?.entity) return;
  const entity = entityHit.entity;
  try {
    entity.typeId;
  } catch {
    return;
  }
  const entId = entity.typeId.replace("minecraft:", "");
  const entSounds = sounds[entId] ?? sounds.default;
  const hitLoc = ev.location;
  const dim = ev.dimension;
  const sound = entSounds[Math.floor(Math.random() * entSounds.length)];
  if (Array.isArray(sound)) {
    for (const s of sound) {
      playSound(dim, s.id, s, {}, hitLoc);
    }
  } else if (sound) {
    playSound(dim, sound.id, sound, {}, hitLoc);
  }
  const entParticles = entityParticles[entId] ?? entityParticles.default;
  const vars = new MolangVariableMap();
  for (const p of entParticles) {
    dim.spawnParticle(p, hitLoc, vars);
  }
});
