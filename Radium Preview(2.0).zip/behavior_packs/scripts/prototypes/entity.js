import { Entity } from "@minecraft/server";
Entity.prototype._vars = {};
Entity.prototype.getRunVar = function(name) {
  return this._vars[name];
};
Entity.prototype.setRunVar = function(name, val) {
  return this._vars[name] = val;
};
Entity.prototype.getHeadHP = function() {
  const hp = this.getRunVar("headHP");
  if (hp !== void 0)
    return hp;
  return this.setRunVar("headHP", 50);
};
Entity.prototype.getArmHP = function() {
  const hp = this.getRunVar("armHP");
  if (hp !== void 0)
    return hp;
  return this.setRunVar("armHP", { l: 100, r: 100 });
};
Entity.prototype.getLegHP = function() {
  const hp = this.getRunVar("legHP");
  if (hp !== void 0)
    return hp;
  return this.setRunVar("legHP", { l: 100, r: 100 });
};
Entity.prototype.damageHead = function(dmg) {
  const hp = this.getHeadHP();
  return this.setRunVar("headHP", Math.max(hp - dmg, 0));
};
Entity.prototype.damageArm = function(side, dmg) {
  const hp = this.getArmHP();
  hp[side] -= dmg;
  return hp[side];
};
Entity.prototype.damageLeg = function(side, dmg) {
  const hp = this.getLegHP();
  hp[side] -= dmg;
  return hp[side];
};

Entity.prototype.getChestHP = function() {
  const hp = this.getRunVar("chestHP");
  if (hp !== void 0)
    return hp;
  return this.setRunVar("chestHP", 100);
};
Entity.prototype.damageChest = function(dmg) {
  const hp = this.getChestHP();
  return this.setRunVar("chestHP", Math.max(hp - dmg, 0));
};
