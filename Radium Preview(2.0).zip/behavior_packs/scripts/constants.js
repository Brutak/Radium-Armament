import { Direction } from "@minecraft/server";
var Constants;
((Constants2) => {
  Constants2.DIR_MAP = {
    [Direction.Up]: { x: 0, y: 1, z: 0 },
    [Direction.Down]: { x: 0, y: -1, z: 0 },
    [Direction.North]: { x: 0, y: 0, z: -1 },
    [Direction.South]: { x: 0, y: 0, z: 1 },
    [Direction.West]: { x: -1, y: 0, z: 0 },
    [Direction.East]: { x: 1, y: 0, z: 0 }
  };
})(Constants || (Constants = {}));
var constants_default = Constants;
export {
  Constants,
  constants_default as default
};
