import {
  EquipmentSlot,
  world
} from "@minecraft/server";
function getMainhand(plr) {
  const inv = plr.getComponent("equippable");
  if (!inv)
    return;
  return inv.getEquipment(EquipmentSlot.Mainhand);
}
function getObjective(id) {
  try {
    const obj = world.scoreboard.getObjective(id);
    if (obj)
      return obj;
  } catch {
  }
  return world.scoreboard.addObjective(id, id);
}
function getScore(obj, ident) {
  if (!ident)
    return;
  try {
    return obj.getScore(ident);
  } catch {
    return;
  }
}
function playSound(dim, sound, soundOpts = {}, query = {}, location = { x: 0, y: 0, z: 0 }) {
  for (const p of dim.getPlayers(Object.assign({
    location,
    minDistance: 0
  }, query))) {
    p.playSound(sound, Object.assign({ location }, soundOpts));
  }
}
function rotateVector(vector, angle) {
  angle = angle * Math.PI / 180;
  return {
    x: vector.x * Math.cos(angle) + vector.z * Math.sin(angle),
    y: vector.y,
    z: -vector.x * Math.sin(angle) + vector.z * Math.cos(angle)
  };
}
export {
  getMainhand,
  getObjective,
  getScore,
  playSound,
  rotateVector
};
