import { world, MolangVariableMap, Player } from "@minecraft/server";
import { getMainhand, playSound  } from "../utils";
import Constants from "../constants";
const ignoreBlocks = [
  "barrier",
  "lantern",
  "cocoa",
  "carved_pumpkin",
  "chorus_flower",
  "chorus_plant",
  "lit_pumpkin",
  "melon_block",
  "pumpkin",
  "turtle_egg",
  "waterlily",
  "cave_vines",
  "cave_vines_body_with_berries",
  "cave_vines_head_with_berries",
  "small_dripleaf_block",
  "big_dripleaf",
  "chain",
];
const glassBlocks = [
  "tinted_glass",
  "glass",
  "glass_pane",
  "stained_glass",
  "black_stained_glass_pane",
  "black_stained_glass",
  "blue_stained_glass_pane",
  "blue_stained_glass",
  "brown_stained_glass_pane",
  "brown_stained_glass",
  "cyan_stained_glass_pane",
  "cyan_stained_glass",
  "gray_stained_glass_pane",
  "gray_stained_glass",
  "green_stained_glass_pane",
  "green_stained_glass",
  "light_blue_stained_glass_pane",
  "light_blue_stained_glass",
  "light_gray_stained_glass_pane",
  "light_gray_stained_glass",
  "lime_stained_glass_pane",
  "lime_stained_glass",
  "magenta_stained_glass_pane",
  "magenta_stained_glass",
  "orange_stained_glass_pane",
  "orange_stained_glass",
  "pink_stained_glass_pane",
  "pink_stained_glass",
  "purple_stained_glass_pane",
  "purple_stained_glass",
  "red_stained_glass_pane",
  "red_stained_glass",
  "white_stained_glass_pane",
  "white_stained_glass",
  "yellow_stained_glass_pane",
  "yellow_stained_glass",
];

//Particles
const bulletParticles = {
  default: ["ra:bullet_hole", "ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  "ra:p250": ["ra:bullet_hole.small", "ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  "ra:remington_870": ["ra:bullet_hole.small.1", "ra:bullet.impact_1", "ra:bullet.impact_sparks.small"],
  "ra:citori_725": ["ra:bullet_hole.small.1", "ra:bullet.impact_1", "ra:bullet.impact_sparks.small"],
  "ra:mini_gun": ["ra:bullet_hole.large", "ra:mini_gun.impact.glow", "ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  "ra:m1_garand": ["ra:bullet_hole.large", "ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  "ra:mosin_nagant": ["ra:bullet_hole.large", "ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  "ra:mp40": ["ra:bullet_hole.small", "ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  "ra:mp40_netherite": ["ra:bullet_hole.small", "ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  "ra:mx115": ["ra:bullet_hole.cyan", "ra:mx115.impact.glow"],
  "ra:mx115_netherite": ["ra:bullet_hole.red.1",  "ra:mx115.impact.glow.red"],
  "ra:rpk": ["ra:bullet_hole.large", "ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  "ra:rpk_polymer": ["ra:bullet_hole.large", "ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  "ra:awm": ["ra:bullet_hole.large", "ra:bullet.impact_1", "ra:bullet.impact_sparks"],
  "ra:sp88": ["ra:sp88.impact_flash", "ra:bullet_hole.lime", "ra:bullet_hole.lime.1", "ra:lime.impact.burst", "ra:sp88.impact.glow", "ra:sp88.impact.glow.1", "ra:sp88.impact_smoke", "ra:sp88.impact_flare", "ra:sp88.impact_smoke.1"],
};

world.afterEvents.projectileHitBlock.subscribe((ev) => {
  const proj = ev.projectile;
  try {
    if (proj.typeId != "ra:bullet.projectile") return;
  } catch {
    return;
  }
  const blockHit = ev.getBlockHit();
  if (!blockHit) return;
  const block = blockHit.block;
  
  for (const igBlockId of ignoreBlocks) {
    if (block.permutation.matches(igBlockId)) return;
  }
  
  const { dimension: dim, source } = ev;
  const vars = new MolangVariableMap();
  const face = blockHit.face;
  const { x, y, z } = Constants.DIR_MAP[face];
  vars.setVector3("variable.block_face", {x, y, z});
  if (!(source instanceof Player)) return;
  const gunId = getMainhand(source)?.typeId ?? "minecraft:air";
  const loc = ev.location;
  vars.setFloat('ra_canbreak', 0);
  if (world.gameRules.mobGriefing) vars.setFloat('ra_canbreak', 1);
  
  const particles = bulletParticles[gunId] ?? bulletParticles.default;
  const partLoc = { x: loc.x + x * 0.01, y: loc.y + y * 0.01, z: loc.z + z * 0.01 };
  for (const p of particles) {
    dim.spawnParticle(p, partLoc, vars);
  }
  if (gunId == "ra:sp88" || gunId == "ra:mx115" || gunId == "ra:mx115_netherite") return;
  playSound(
    dim,
    "bullet_impact",
    { pitch: Math.random() * 1 + 0.75, volume: 1 },
    { maxDistance: 60 },
    partLoc
  );
});
