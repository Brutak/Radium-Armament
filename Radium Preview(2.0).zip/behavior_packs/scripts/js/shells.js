import { world, MolangVariableMap, Player } from "@minecraft/server";
import { getMainhand } from "../utils";
import Constants from "../constants";
import Vector from "../Vector";
const ignoreBlocks = [
  "barrier",
  "lantern",
  "glass",
  "glass_pane",
  "stained_glass",
  "black_stained_glass_pane",
  "black_stained_glass",
  "blue_stained_glass_pane",
  "blue_stained_glass",
  "brown_stained_glass_pane",
  "brown_stained_glass",
  "cyan_stained_glass_pane",
  "cyan_stained_glass",
  "gray_stained_glass_pane",
  "gray_stained_glass",
  "green_stained_glass_pane",
  "green_stained_glass",
  "light_blue_stained_glass_pane",
  "light_blue_stained_glass",
  "light_gray_stained_glass_pane",
  "light_gray_stained_glass",
  "lime_stained_glass_pane",
  "lime_stained_glass",
  "magenta_stained_glass_pane",
  "magenta_stained_glass",
  "orange_stained_glass_pane",
  "orange_stained_glass",
  "pink_stained_glass_pane",
  "pink_stained_glass",
  "purple_stained_glass_pane",
  "purple_stained_glass",
  "red_stained_glass_pane",
  "red_stained_glass",
  "white_stained_glass_pane",
  "white_stained_glass",
  "yellow_stained_glass_pane",
  "yellow_stained_glass",
  "bamboo",
  "cocoa",
  "carved_pumpkin",
  "chorus_flower",
  "chorus_plant",
  "lit_pumpkin",
  "melon_block",
  "pumpkin",
  "turtle_egg",
  "waterlily",
  "cave_vines",
  "cave_vines_body_with_berries",
  "cave_vines_head_with_berries",
  "small_dripleaf_block",
  "big_dripleaf",
  "chain",
];
const bulletParticle = {
  default: "ra:m203.dirty.impact_goo",
};
const impactParticle = {
  default: "ra:m203.impact_ground",
};
const impactParticle2 = {
  default: "ra:m203.impact_ground.small",
};
world.afterEvents.projectileHitBlock.subscribe((ev) => {
  const proj = ev.projectile;
  try {
    if (proj.typeId != "ra:m79_grenade.projectile") return;
  } catch {
    return;
  }
  const blockHit = ev.getBlockHit();
  if (!blockHit) return;
  const block = blockHit.block;

  for (const igBlockId of ignoreBlocks) {
    if (block.permutation.matches(igBlockId)) return;
  }
  const skinId = proj.getComponent("minecraft:skin_id")?.value ?? 0;
  if (skinId == 3) {

    const { dimension: dim, source } = ev;
    const vars = new MolangVariableMap();
    const face = blockHit.face;
    const { x, y, z } = Constants.DIR_MAP[face];
    vars.setVector3("variable.block_face", {x, y, z});
    if (!(source instanceof Player)) return;
    const skinId = getMainhand(source)?.typeId ?? "minecraft:air";
    const particle = bulletParticle[skinId] ?? bulletParticle.default;
    const loc = ev.location;
    const partLoc = { x: loc.x + x * 0.01, y: loc.y + y * 0.01, z: loc.z + z * 0.01 };
    dim.spawnParticle(particle, partLoc, vars);
  }

  const mobGriefing = proj.hasComponent("is_stunned");
  if (!mobGriefing && (skinId == 1 || skinId == 4)) {

    const { dimension: dim, source } = ev;
    const vars = new MolangVariableMap();
    const face = blockHit.face;
    const { x, y, z } = Constants.DIR_MAP[face];
    vars.setVector3("variable.block_face", {x, y, z});
    if (!(source instanceof Player)) return;
    const skinId = getMainhand(source)?.typeId ?? "minecraft:air";
    const particle = impactParticle[skinId] ?? impactParticle.default;
    const loc = ev.location;
    const partLoc = { x: loc.x + x * 0.0125, y: loc.y + y * 0.0125, z: loc.z + z * 0.0125 };
    dim.spawnParticle(particle, partLoc, vars);
  }
  if (!mobGriefing && (skinId == 2 || skinId == 5)) {

    const { dimension: dim, source } = ev;
    const vars = new MolangVariableMap();
    const face = blockHit.face;
    const { x, y, z } = Constants.DIR_MAP[face];
    vars.setVector3("variable.block_face", {x, y, z});
    if (!(source instanceof Player)) return;
    const skinId = getMainhand(source)?.typeId ?? "minecraft:air";
    const particle = impactParticle2[skinId] ?? impactParticle2.default;
    const loc = ev.location;
    const partLoc = { x: loc.x + x * 0.0125, y: loc.y + y * 0.0125, z: loc.z + z * 0.0125 };
    dim.spawnParticle(particle, partLoc, vars);
  }
});
