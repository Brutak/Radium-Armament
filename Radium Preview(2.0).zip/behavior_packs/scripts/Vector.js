const Vector = {
  subtract(a, b) {
    return { x: a.x - b.x, y: a.y - b.y, z: a.z - b.z };
  },
  add(a, b) {
    return { x: a.x + b.x, y: a.y + b.y, z: a.z + b.z };
  },
  multiply(a, b) {
    if (typeof b === "number") return { x: a.x * b, y: a.y * b, z: a.z * b };
    return { x: a.x * b.x, y: a.y * b.y, z: a.z * b.z };
  },
  div(a, b) {
    if (typeof b === "number") return { x: a.x / b, y: a.y / b, z: a.z / b };
    return { x: a.x / b.x, y: a.y / b.y, z: a.z / b.z };
  },
  length(a) {
    return Math.sqrt(a.x * a.x + a.y * a.y + a.z * a.z);
  },
  normalized(a) {
    return Vector.div(a, Vector.length(a));
  },
};

export default Vector;
