import { world, MolangVariableMap, Player } from "@minecraft/server";
import Constants from "../constants";
const ignoreBlocks = [
  "barrier",
];
const bulletParticle = {
  default: "ra:m203.dirty.impact_goo.1",
};
world.afterEvents.projectileHitBlock.subscribe((ev) => {
  const proj = ev.projectile;
  try {
    if (proj.typeId != "ra:dirty.droplets") return;
  } catch {
    return;
  }
  const blockHit = ev.getBlockHit();
  if (!blockHit) return;
  const block = blockHit.block;

  for (const igBlockId of ignoreBlocks) {
    if (block.permutation.matches(igBlockId)) return;
  }

  const { dimension: dim, source } = ev;
  const vars = new MolangVariableMap();
  const face = blockHit.face;
  const { x, y, z } = Constants.DIR_MAP[face];
  vars.setVector3("variable.block_face", {x, y, z});
  const particle = bulletParticle.default;
  const loc = ev.location;
  const partLoc = { x: loc.x + x * 0.01, y: loc.y + y * 0.01, z: loc.z + z * 0.01 };
  dim.spawnParticle(particle, partLoc, vars);
});
